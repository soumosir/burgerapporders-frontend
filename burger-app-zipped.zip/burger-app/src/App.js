import React from 'react';
import Burger from './components/burger/burger'
import Order from './components/order/order'
import Navbar from './components/navbar/navbar'
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <Navbar />
    <div className="App">
      
      <Switch>
      <Route path="/" exact component={Burger}/>
      <Route path="/order" exact component={Order}/>
      </Switch>
      
    </div>
    </Router>
  );
}

export default App;


