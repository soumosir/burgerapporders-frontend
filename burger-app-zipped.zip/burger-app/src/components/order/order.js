import React, { Component } from "react";
// import {Link} from 'react-router-dom';

class Order extends Component {
    constructor(props) {
        super(props);
        this.state = {
            accessToken: '',
            is_loading: true,
            error : null,
            burger : {},
            username : "",
            cutlets: 0,
            salad: "No",
            slices: 0,
            totalcost: 10,
            errormessage : "",
            buns : 2,
        };
    }

    

    componentDidMount() {
        
        this.setState({
                    
                    is_loading: false,
                    error: null,
                })
    }
   
    componentWillUnmount() {

    }

    submitData(event){

        let query_string = "";
        const { username,buns,salad,cutlets,slices,totalcost} = this.state;

        

        let item = {
            'username' : username,
            'buns' : parseInt(buns),
            'salad': salad=="yes"?true:false,
            'slices': parseInt(slices),
            'cutlets': parseInt(cutlets),
            'cost': parseInt(totalcost)

        }
        
        const purl = "http://127.0.0.1:8000/";
        
        // const url = purl+query_string;

        console.log(this.state);

        fetch(purl, {
                method: 'post',
                body: JSON.stringify(item)
            })
        .then(res => res.json())
        .then(response => this.setBurgers(response))
        .catch(error => this.handleError(error));



    }

    setBurgers(response) {
        // this.setState({
        // this.state.loading = false;
        // })
        console.log(response.statusCode);
        if(response.statusCode=='201'){
        
        console.log(" response -- ",response['data'])
        this.setState({
            burger : response['data'],
            is_loading: false,
            error: null,
            username : "",
            cutlets: 0,
            salad: "No",
            slices: 0,
            totalcost: 10,
            errormessage : "",
            buns : 2,

        })
        }
        else{
            this.setState({
                burger : {},
                is_loading : false,
                error: null,
                username : "",
                cutlets: 0,
                salad: "No",
                slices: 0,
                totalcost: 10,
                errormessage : "",
                buns : 2,
            })
        }
        alert(" Order placed ")
        
        
        
    }

    handleError(errorm) {
        this.setState({
        is_loading: false,
        error: "post_failed",
        username : "",
        cutlets: 0,
        salad: "No",
        slices: 0,
        totalcost: 10,
        errormessage : "",
        buns : 2,
        });
    }


    validate(){
        const { username} = this.state;
        if (username=="" || username==null) return false;
       
        return true;

    }

    mySubmitHandler = (event) => {
        event.preventDefault();
        console.log("  in handle submit -- ",this.errormessage)
        if (this.errormessage == null){
            if(this.validate()) this.submitData(event);
            else this.setState({errormessage: "One or more fields are not proper"});
        }
        else{
            this.setState({errormessage: "Error submitting form"});
        }    
      }

    myChangeHandler = (event) => {
        let nam = event.target.name;
        let val = event.target.value;
        let err = '';
        if (nam === "username") {
          if (val =="") {
            err = <strong>You must not leave the field's blank</strong>;
          }
        }
        this.setState({errormessage: err});
        this.setState({[nam]: val});
    }

   
    handleQuarterChange = (event) => {
        let nam = event.target.name;
        this.setState({[nam]: event.target.value});

        let {slices,cutlets,salad} = this.state;
        let total = 10;
        if(nam=="slices"){
            total+= parseInt(event.target.value);
            total+= parseInt(cutlets)*2;
            if (salad=="yes"){ total+= 5}
        }
        else if(nam=="cutlets"){
            total+= parseInt(event.target.value)*2;
            total+= parseInt(slices);
            if (salad=="yes"){ total+= 5}
        }
        else if(nam=="salad"){
            total+= parseInt(cutlets)*2;
            total+= parseInt(slices)
            if (event.target.value=="yes"){ total+= 5}
        }
       
        this.setState({totalcost:total});
    }
    // handleQuarterChange2 = (event) => {
    //     this.setState({cutlets:event.target.value});
    // }
    


    render() {
        const {  is_loading, error, username, salad,slices,cutlets,totalcost,buns,burger } = this.state;
        
        if (is_loading) {
            return <p>Loading ...</p>;
        }

        if(error!=null){
            return <p>{error}</p>;
        }
        const navStyle = {
            color: "grey"
        };

        return (
            
            <div>
                <div className="bigbox">

                    <div className="filterflexbox">
                    <span>Order your burger</span>

{/* Name or guy who order
Bun = 2 (fix price Rs 5 each bun)
salad = yes or no (price Rs 5)
Cheese Slices = (Rs 1 per slice)
cutlets = (Rs 2 per piece) */}

                        <form onSubmit={this.mySubmitHandler}>
                            
                            <p>Enter Name:</p>
                            <input
                                value={username}
                                type='text'
                                name='username'
                                onChange={this.myChangeHandler}
                            />

                            <p>Enter number of buns:</p>
                            <input
                                value={buns}
                                type='text'
                                name='buns'
                                disabled = "disabled"
                                // onChange={this.myChangeHandler}
                            />
                            
                             
                            
                            <p>Salad:</p>
                            <select value={salad} name='salad' onChange={this.handleQuarterChange} >
                                <option value="no">No</option>
                                <option value="yes">Yes (Rs 5)</option>
                                
                            </select>
                            <p>Enter quantity of cheese slices :</p>
                            <select value={slices}  name='slices' onChange={this.handleQuarterChange} >
                               
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                
                            </select>

                            <p>Enter quantity of cultlets :</p>
                            <select value={cutlets}  name='cutlets' onChange={this.handleQuarterChange} >
                    
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                
                                
                            </select>
                            
                            {this.state.errormessage}
                            <br></br>
                            <input type='submit' />
                        </form>



                    </div>
                    <div className="customflexbigbox">
                    Cost of the burger
                    <div className="custom2flexbox">
                      Name of the user : {username}
                    </div> 
                    <div className="custom2flexbox">
                      Number of buns : {buns}
                    </div> 
                    <div className="custom2flexbox">
                        Number of slices : {slices}
                    </div> 
                    <div className="custom2flexbox">
                       salad present? : {salad}
                    </div> 
                    <div className="custom2flexbox">
                      number of cutlets : {cutlets}
                    </div> 
                      
                        
                    <div className="custom2flexbox">
                        total cost : {totalcost}
                    </div>  

                    {/* <div className="custom2flexbox">
                     {burger}
                    </div>     */}

                        
                    </div> 

                   

                </div>
                
                 
            </div>
        );
    }
}

export default Order;