import React, { Component } from "react";
// import {Link} from 'react-router-dom';

class Burger extends Component {
    constructor(props) {
        super(props);
        this.state = {
            accessToken: '',
            is_loading: true,
            error : null,
            burgers : [],
            username : "",
            aggregatedcost : 0,
            errormessage : "",
            
        };
    }

    sudofetch(username=null){
        let default_obj = [{ "order_id" : 1, "username":"soumosir", "burger":{"desp":"2-1-1"},"price": 200 },
        { "order_id" : 2, "username":"jack", "burger":{"desp":"2-1-1"},"price": 400 }]
        
        if(username == null){
            return { "statusCode":200, "data" : default_obj };
        }
        else{
            console.log(" username ",username);
            let queried_obj = [];
            for(let i=0;i<default_obj.length;i++){
                if(default_obj[i]["username"]===username){
                        queried_obj.push(default_obj[i])
                }
            }
            if (queried_obj.length>0)
            return { "statusCode":200, "data" : queried_obj };
            else return { "statusCode":404, "data" : [], "message": " no user of the username exists" };
           
        }
        
    }

    componentDidMount() {
        const purl = "http://127.0.0.1:8000/";
       
        console.log(" in component mounting --url ",purl)
        // this.setBurgers(this.sudofetch())
        fetch(purl)
        .then(res => res.json())
        .then(response => this.setBurgers(response))
        .catch(error => this.handleError(error));
    }
    setBurgers(response) {
        //this.setState({
        //this.state.loading = false;
        //})
        console.log(response.statusCode);
        if(response.statusCode=='200'){
        
        console.log(" response -- ",response['data'])
        this.setState({
            aggregatedcost : response['totalcost'],
            burgers : response['data'],
            is_loading: false,
            error: null,
        })
        }
        else{
            this.setState({
                aggregatedcost : 0,
                burgers : [],
                is_loading : false,
                error: null,
            })
        }
        
        
        
    }

    handleError(errorm) {
        this.setState({
        aggregatedcost : 0,
        is_loading: false,
        error: "fetch_failed"
        });
    }

    componentWillUnmount() {

    }

    loadData(event){

        let query_string = "";
        const { username} = this.state;

        

        if (username!="") query_string+="?username="+username;
        
        const purl = "http://127.0.0.1:8000/";
        
        const url = purl+query_string;

        // this.setBurgers(this.sudofetch(username))
        fetch(url)
        .then(res => res.json())
        .then(response => this.setBurgers(response))
        .catch(error => this.handleError(error));



    }
    validate(){
        const { username } = this.state;
        if (username=="" || username==null) return false;
      
        return true;

    }

    mySubmitHandler = (event) => {
        event.preventDefault();
        console.log("  in handle submit -- ",this.errormessage)
        if (this.errormessage == null){
            if(this.validate()) this.loadData(event);
            else this.setState({errormessage: "One or more fields are not proper"});
        }
        else{
            this.setState({errormessage: "Error submitting form"});
        }    
      }

    myChangeHandler = (event) => {
        let nam = event.target.name;
        let val = event.target.value;
        let err = '';
        if (nam === "username") {
          if (val =="") {
            err = <strong>You must not leave the field's blank</strong>;
          }
        }
        this.setState({errormessage: err});
        this.setState({[nam]: val});
    }

    

    render() {
        const { burgers, is_loading, error, username,aggregatedcost } = this.state;
        
        if (is_loading) {
            return <p>Loading ...</p>;
        }

        if(error!=null){
            return <p>{error}</p>;
        }
        const navStyle = {
            color: "grey"
        };

        return (
            
            <div>
                <div className="bigbox">

                    <div className="filterflexbox">
                    <span>Filters Available</span>



                        <form onSubmit={this.mySubmitHandler}>
                            
                            <p>Enter Username:</p>
                            <input
                                value={username}
                                type='text'
                                name='username'
                                onChange={this.myChangeHandler}
                            />
                            
                            
                            {this.state.errormessage}
                            <br></br>
                            <input type='submit' />
                        </form>



                    </div>

                    <div className="customflexbigbox">
                    Orders : total cost : {aggregatedcost}
                   
                    <div className="custom2flexbox">
                    <span >Id </span>
                    <span >Username</span>
                    <span >Buns </span>
                    <span >Salad</span>
                    <span >Cutlets</span>
                    <span>Slices</span>
                    <span>Cost</span>
                    </div>    
                        {burgers.length<=0?" No orders available ":""}
                        
                       
                        {burgers.map(hit =>
                        
                        <h4 key={hit.id}>
                            
                            {/* <span>Order id : {hit.order_id}</span> */}
                            
                            <div className="customflexbox">
                            <span >{hit.id} </span>
                            <span >{hit.username} </span>
                            <span >{hit.buns} </span>
                            <span >{ hit.salad?"yes":"no"} </span>
                            <span >{hit.cutlets} </span>
                            <span >{hit.slices} </span>
                            {/* <span >{hit.burger} </span> */}
                            <span> Rs. {hit.cost} </span>
                            <br></br>
                            

                            </div>
                            {/* <span>Start time :: </span><span className="customflex">{hit.start_time}</span>
                        */}
                        </h4>
                        )}
                    </div> 

                </div>
                
                 
            </div>
        );
    }
}

export default Burger;